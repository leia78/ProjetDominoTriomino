#include<structures.h>

typdef struct{

}d; 
