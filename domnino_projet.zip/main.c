#include "structures.h"

int main (void)
{	
	
	SDL_Surface *ecran=NULL;       
	accueil(ecran);
	SDL_Quit();
	return 0;
}
