#include"structures.h"
extern int *ordre,nbjoueur,type;
int dj1,dj2,dj3,dj4,dord,i;
extern piece *pj1,*pj2,*pj3,*pj4,*pord,*p,*pioche;
void debut_jeu(){
		int endgame=0;
					if(nbjoueur == 1){
						dj1=7;
						dord=7;
					}
					else if(nbjoueur == 2){
						dj1=7;
						dj2=7;
					}
					else if(nbjoueur == 3){
						dj1=6;
						dj2=6;
						dj3=6;
					}
					else if(nbjoueur == 4){
						dj1=6;
						dj2=6;
						dj3=6;
						dj4=6;
					}



		while(!endgame){	if(nbjoueur==1){
						
							if(dj1 == 0 || dord ==0){endgame = 1;}
							else{
							for(i=0;i<2;i++){
								switch(ordre[i]){
										case 1:play(1);break;
										case 0:play(0);break;
										}
						
									}
								}	
						}		
					else if(nbjoueur==2){
						
						if(dj1 == 0 || dj2 ==0){endgame = 1;}
						else{
						for(i=0;i<2;i++){
								switch(ordre[i]){
										case 1:play(1);break;
										case 2:play(2);break;
										}
								}
							}
						}

					
						
					
					else if(nbjoueur==3){
					
					if(dj1 == 0 || dj2 ==0 || dj3 ==0){endgame = 1;}
						else{
						for(i=0;i<3;i++){
								switch(ordre[i]){
										case 1:play(1);break;
										case 2:play(2);break;
										case 3:play(3);break;
										}
								}
					
						}
					}
					else if(nbjoueur==4){
						
						if(dj1 == 0 || dj2 ==0 || dj3 ==0 || dj4 ==0){endgame = 1;}
						else{
						for(i=0;i<4;i++){
								switch(ordre[i]){
										case 1:play(1);break;
										case 2:play(2);break;
										case 3:play(3);break;
										case 4:play(4);break;
										}
								}
						}
					}

				
		
				}
}
void play(int j){

	switch(j){	case 0:printf("0\n");dord=dord-1;break;
			case 1:printf("1\n");dj1=dj1-1;break;
			case 2:printf("2\n");dj2=dj2-1;break;
			case 3:printf("3\n");dj3=dj3-1;break;
			case 4:printf("4\n");dj4=dj4-1;break;
	}

}




















