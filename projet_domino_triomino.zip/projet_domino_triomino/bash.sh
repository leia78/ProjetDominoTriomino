gcc acceuil.c main.c debut_jeu.c pseudo.c dominos.c triomino.c affiche_trioO.c fonction.c `sdl-config --cflags --libs` -lm -lSDL_ttf
