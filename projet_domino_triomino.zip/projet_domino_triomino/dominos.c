#include"structures.h"
extern piece *pj1,*pj2,*pj3,*pj4,*pord,*p,*pioche;
extern int *ordre,nbjoueur,type;
piece * init_piece(int type){
	piece *p;
	int i,j,s=sizeof(piece),d=0,a=0, b=0;	
	p = (piece*) malloc (28*sizeof(piece));

	for(i=0;i<28;i++)
	{
			p[i].number = (int*) malloc (2*sizeof(int));
	}


	for(i=0;i<28;i++)
	{
		for(j=0;j<2;j++)
		{
			if(j==0)
			{
				p[i].number[j] = a;
			}
			else
			{
				p[i].number[j] = b;
				b++;
			}
			if(b==7)
			{
				a++;
				b=a;
			}
		}	
	}
	
return p;
}
void melange(int nbjoueur,piece *p){
	int i,b;
	piece *p1=NULL;
	srand(time(0));
	
	p1= (piece*) malloc (28*sizeof(piece));
	piece * temp = NULL;
	temp=(piece*) malloc(sizeof(piece));
	p1=p;
	for(i=0;i<28;i++)
		{
			temp[0]=p1[i];
    			int randomIndex = rand() % 28;

    			p1[i]           = p1[randomIndex];
    			p1[randomIndex] = temp[0];
			
		}
	if(nbjoueur==1)
		{
			pj1=(piece*) malloc(7*sizeof(piece));
			pord=(piece*) malloc(7*sizeof(piece));
			pioche=(piece*) malloc(14*sizeof(piece));
			for(i=0;i<7;i++)
			{
				pj1[i]=p1[i];
				pord[i]=p1[i+7];
			}	
			for(i=0;i<14;i++)
			{
			 	pioche[i]=p1[i+14];
			}			
		}
	else if(nbjoueur==2)
		{
			pj1=(piece*) malloc(7*sizeof(piece));
			pj2=(piece*) malloc(7*sizeof(piece));
			pioche=(piece*) malloc(14*sizeof(piece));
			for(i=0;i<7;i++)
			{
				pj1[i]=p1[i];
				pj2[i]=p1[i+7];
				
			}
			for(i=0;i<14;i++)
			{
			 	pioche[i]=p1[i+14];
			}
		}
	else if(nbjoueur==3)
		{
			pj1=(piece*) malloc(6*sizeof(piece));
			pj2=(piece*) malloc(6*sizeof(piece));
			pj3=(piece*) malloc(6*sizeof(piece));
			pioche=(piece*) malloc(10*sizeof(piece));
			for(i=0;i<7;i++)
			{
				pj1[i]=p1[i];
				pj2[i]=p1[i+6];
				pj3[i]=p1[i+12];
			}
			for(i=0;i<10;i++)
			{
			 	pioche[i]=p1[i+18];
			}
		}
	else if(nbjoueur==4)
		{
			pj1=(piece*) malloc(6*sizeof(piece));
			pj2=(piece*) malloc(6*sizeof(piece));
			pj3=(piece*) malloc(6*sizeof(piece));
			pj4=(piece*) malloc(6*sizeof(piece));
			pioche=(piece*) malloc(4*sizeof(piece));
			for(i=0;i<6;i++)
			{
				pj1[i]=p1[i];
				pj2[i]=p1[i+6];
				pj3[i]=p1[i+12];
				pj4[i]=p1[i+18];
			}
			for(i=0;i<4;i++)
			{
			 	pioche[i]=p1[i+24];
			}
		}

}
void distribuer(SDL_Surface *ecran){
	SDL_Surface *image=NULL,*back=NULL;
	
	SDL_Rect  posDj1,posDord,posDj2,posDj3,posDj4,posDpioche;
	posDj1.x=200;posDj1.y=680;
	posDord.x=200;posDord.y=10;
	posDpioche.x=1130;posDpioche.y=10;
	back=SDL_LoadBMP("domino/back.bmp");
	SDL_BlitSurface(back, NULL, ecran, &posDpioche);
	int i,l,h;
char e[2],u[2];
	char *s1 = ".bmp", *c; 
	if(nbjoueur==1){
			for(i=0;i<7;i++){
				l=pj1[i].number[0];
				h=pj1[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				SDL_BlitSurface(image, NULL, ecran, &posDj1);
				posDj1.x=posDj1.x+68;
				pj1[i].pos.x=posDj1.x;
				pj1[i].pos.y=posDj1.y;
			}
			for(i=0;i<7;i++){
				l=pord[i].number[0];
				h=pord[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				
				SDL_BlitSurface(image, NULL, ecran, &posDord);
				SDL_BlitSurface(back, NULL, ecran, &posDord);
				posDord.x=posDord.x+68;
				pord[i].pos.x=posDord.x;
				pord[i].pos.y=posDord.y;
			}
			
	}
	else if(nbjoueur==2){
			posDj1.x=200;posDj1.y=680;
			posDj2.x=200;posDj2.y=10;
			for(i=0;i<7;i++){
				l=pj1[i].number[0];
				h=pj1[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				SDL_BlitSurface(image, NULL, ecran, &posDj1);
				posDj1.x=posDj1.x+68;
				pj1[i].pos.x=posDj1.x;
				pj1[i].pos.y=posDj1.y;
			}
			for(i=0;i<7;i++){
				l=pj2[i].number[0];
				h=pj2[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				back=SDL_LoadBMP("domino/back.bmp");
				SDL_BlitSurface(image, NULL, ecran, &posDj2);
				//SDL_BlitSurface(back, NULL, ecran, &posDj2);
				posDj2.x=posDj2.x+68;
				pj2[i].pos.x=posDj2.x;
				pj2[i].pos.y=posDj2.y;
			}
	}	
	
	else if(nbjoueur==3){
			posDj1.x=10;posDj1.y=680;
			posDj2.x=700;posDj2.y=680;
			posDj3.x=200;posDj3.y=10;
			for(i=0;i<6;i++){
				l=pj1[i].number[0];
				h=pj1[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				SDL_BlitSurface(image, NULL, ecran, &posDj1);
				posDj1.x=posDj1.x+68;
				pj1[i].pos.x=posDj1.x;
				pj1[i].pos.y=posDj1.y;
			}
			for(i=0;i<6;i++){
				l=pj2[i].number[0];
				h=pj2[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				back=SDL_LoadBMP("domino/back.bmp");
				SDL_BlitSurface(image, NULL, ecran, &posDj2);
				//SDL_BlitSurface(back, NULL, ecran, &posDj2);
				posDj2.x=posDj2.x+68;
				pj2[i].pos.x=posDj2.x;
				pj2[i].pos.y=posDj2.y;
			}
			for(i=0;i<6;i++){
				l=pj3[i].number[0];
				h=pj3[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				back=SDL_LoadBMP("domino/back.bmp");
				SDL_BlitSurface(image, NULL, ecran, &posDj3);
				//SDL_BlitSurface(back, NULL, ecran, &posDj3);
				posDj3.x=posDj3.x+68;
				pj3[i].pos.x=posDj3.x;
				pj3[i].pos.y=posDj3.y;
			}
	}
	else if(nbjoueur==4){
			posDj1.x=10;posDj1.y=680;
			posDj2.x=700;posDj2.y=680;
			posDj3.x=10;posDj3.y=10;
			posDj4.x=700;posDj4.y=10;
			for(i=0;i<6;i++){
				l=pj1[i].number[0];
				h=pj1[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				SDL_BlitSurface(image, NULL, ecran, &posDj1);
				posDj1.x=posDj1.x+68;
				pj1[i].pos.x=posDj1.x;
				pj1[i].pos.y=posDj1.y;
			}
			for(i=0;i<6;i++){
				l=pj2[i].number[0];
				h=pj2[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				back=SDL_LoadBMP("domino/back.bmp");
				SDL_BlitSurface(image, NULL, ecran, &posDj2);
				//SDL_BlitSurface(back, NULL, ecran, &posDj2);
				posDj2.x=posDj2.x+68;
				pj2[i].pos.x=posDj2.x;
				pj2[i].pos.y=posDj2.y;
			}
			for(i=0;i<6;i++){
				l=pj3[i].number[0];
				h=pj3[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				back=SDL_LoadBMP("domino/back.bmp");
				SDL_BlitSurface(image, NULL, ecran, &posDj3);
				//SDL_BlitSurface(back, NULL, ecran, &posDj3);
				posDj3.x=posDj3.x+68;
				pj3[i].pos.x=posDj3.x;
				pj3[i].pos.y=posDj3.y;
			}
			for(i=0;i<6;i++){
				l=pj4[i].number[0];
				h=pj4[i].number[1];
				sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
				strcat(e,u);
				c = concat(e,s1);
				image = SDL_LoadBMP(c);
				back=SDL_LoadBMP("domino/back.bmp");
				SDL_BlitSurface(image, NULL, ecran, &posDj4);
				//SDL_BlitSurface(back, NULL, ecran, &posDj4);
				posDj4.x=posDj4.x+68;
				pj4[i].pos.x=posDj4.x;
				pj4[i].pos.y=posDj4.y;
			}
	}
	
}
void ordreJ(){

if(nbjoueur==1){
		ordre=(int *) malloc(2*sizeof(int));
		if(maxpj(pj1)>=maxpj(pord)){
					ordre[0]=1;
					ordre[1]=0;
				 }
		else{
					ordre[0]=0;
					ordre[1]=1;
			}
	}
else if(nbjoueur==2){
		ordre=(int *) malloc(2*sizeof(int));
		if(maxpj(pj1)>=maxpj(pj2)){
					ordre[0]=1;
					ordre[1]=2;
				 }
		else{
					ordre[0]=2;
					ordre[1]=1;
			}

	}


else if(nbjoueur==3){
	ordre=(int *) malloc(3*sizeof(int));
	if(maxpj(pj1)>maxpj(pj2)){
		if(maxpj(pj1)>maxpj(pj3) && maxpj(pj2)>maxpj(pj3)){
			ordre[0]=1;
			ordre[1]=2;
			ordre[2]=3;
		}
		else if(maxpj(pj1)<maxpj(pj3) && maxpj(pj2)<maxpj(pj3)){
			ordre[0]=3;
			ordre[1]=1;
			ordre[2]=2;
		}
		
		else{
			ordre[0]=1;
			ordre[1]=3;
			ordre[2]=2;
		}
	}
	else{
		if(maxpj(pj1)>maxpj(pj3) && maxpj(pj2)>maxpj(pj3)){
			ordre[0]=2;
			ordre[1]=1;
			ordre[2]=3;
		}
		else if(maxpj(pj1)<maxpj(pj3) && maxpj(pj2)<maxpj(pj3)){
			ordre[0]=3;
			ordre[1]=2;
			ordre[2]=1;
		}
		
		else{
			ordre[0]=2;
			ordre[1]=3;
			ordre[2]=1;
		}
	}
/*printf("%d\n",ordre[0]);
printf("%d\n",ordre[1]);
printf("%d\n",ordre[2]);*/
}


else if(nbjoueur==4){
	ordre=(int *) malloc(4*sizeof(int));
	int max=0,i,min,t[4]={maxpj(pj1),maxpj(pj2),maxpj(pj3),maxpj(pj4)},indiceMax,indiceMin,j2,j3;
	/*printf("%d\n",t[0]);
	printf("%d\n",t[1]);
	printf("%d\n",t[2]);
	printf("%d\n",t[3]);*/
	for(i=0;i<4;i++){
			 	if(max<t[i]){
						max=t[i];
						indiceMax=i+1;
					}
			}
	ordre[0]=indiceMax;
	min=max;
	for(i=0;i<4;i++){
			 	if(min>=t[i]){
						min=t[i];
						indiceMin=i+1;
						}
			}
	
	
	ordre[3]=indiceMin;
	j2=0;
	for(i=0;i<4;i++){
				if(i!=indiceMax-1&&i!=indiceMin-1&&j2<t[i]){
								j2=t[i];
								ordre[1]=i+1;
						}
			}
	for(i=0;i<4;i++){
				if(i!=indiceMax-1&&i!=indiceMin-1&&t[i]<j2){
								ordre[2]=i+1;
						}
			}
/*printf("%d\n",ordre[0]);
printf("%d\n",ordre[1]);
printf("%d\n",ordre[2]);
printf("%d\n",ordre[3]);*/
}
}
