#include "structures.h"

int main (void)
{	
	
	SDL_Surface *ecran=NULL;       
	TTF_Init();    
	accueil(ecran);
	TTF_Quit();
	SDL_Quit();
	return 0;
}
