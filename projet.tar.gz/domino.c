#include "structures.h"

piece * init_dom(int type)
{
	piece *p;
	int i,j,s=sizeof(piece),d=0,a=0, b=0;	

	p = (piece*) malloc (28*sizeof(piece));

	for(i=0;i<28;i++)
	{
		p[i].number = (int*) malloc (2*sizeof(int));
	}


	for(i=0;i<28;i++)
	{
		for(j=0;j<2;j++)
		{
			if(j==0)
			{
				p[i].number[j] = a;
			}
			else
			{
				p[i].number[j] = b;
				b++;
			}
			if(b==7)
			{
				a++;
				b=a;
			}
		}	
	}
	
	return p;
}

void melange(int nbjoueur,piece *p)
{
	int i,b;
	piece *p1=NULL;
	
	p1= (piece*) malloc (28*sizeof(piece));
	
	for(i=0;i<28;i++)
	{
		b =rand()%28;
		p1[i]= p[b];
	}
	
	if(nbjoueur=1)
	{
		pj1=(piece*) malloc(7*sizeof(piece));
		pord=(piece*) malloc(7*sizeof(piece));
		for(i=0;i<7;i++)
		{
			pj1[i]=p1[i];
			pord[i]=p1[i+7];
		}				
	}
	return;
}

void board_d(SDL_Surface *ecran)
{
	SDL_Event event;
	int continuer=1,i;
	SDL_Surface  *a=NULL,*b=NULL;
	SDL_Rect  posAccueil,posBoard;
	a = SDL_LoadBMP("accueil/menu-bg.bmp");
	b=SDL_LoadBMP("accueil/board.bmp");
	
	posBoard.x=200;
	posBoard.y=150;

	posAccueil.x = 0; 
	posAccueil.y = 0;
	
	SDL_BlitSurface(a, NULL, ecran, &posAccueil);
	SDL_BlitSurface(b, NULL, ecran, &posBoard);
	SDL_Flip(ecran);
	melange(nbjoueur,p);
	
	for(i=0;i<7;i++)
	{
		printf("%d\t%d\n",pj1[i].number[0],pj1[i].number[1]);
		printf("%d\t%d\n",pord[i].number[0],pord[i].number[1]);
	}
	
	while (continuer)
	{
    	SDL_WaitEvent(&event); 
    	switch(event.type) 
    	{
       		case SDL_QUIT : 
           		continuer = 0;
           		break;
			/*case SDL_MOUSEBUTTONUP:

			if (event.button.x>=posBquitter.x && event.button.x<=posBquitter.x+278 && event.button.y>=posBquitter.y && event.button.y<=posBquitter.y+80)
			{
				continuer=0;break;
			}
			else if (event.button.x>=posBjouer.x && event.button.x<=posBjouer.x+278 && event.button.y>=posBjouer.y && event.button.y<=posBjouer.y+80)
			{
				continuer=0;jeu(ecran);init_piece(2);
			}*/
    	}
		switch( event.key.keysym.sym )
        {
			case SDLK_ESCAPE: continuer = 0; break;
        }
	}
	
	return;
}
