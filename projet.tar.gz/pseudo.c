#include "structures.h"

void nomJ (char *pseudo, int numj, SDL_Surface *ecran)
{
    char nom[20];
    int t_nom=0, i, continuer=1;
    SDL_Color couleurBlanc = {255, 255, 255};
    SDL_Surface *texte = NULL,*a=NULL;
    SDL_Rect positionTxt, posAccueil;
    SDL_Event event;
    TTF_Font *police = NULL;

    police = TTF_OpenFont("calibri.ttf",25);

//Obligé de blit du texte sinon la fonction se ferme
	if(numj==1)
		texte = TTF_RenderUTF8_Blended(police, "Joueur 1 tapez votre pseudo et appuyez sur entrée.", couleurBlanc);
	else if (numj==2)
	texte = TTF_RenderUTF8_Blended(police, "Joueur 2 tapez votre pseudo et appuyez sur entrée.", couleurBlanc);
	else if (numj==3)
		texte = TTF_RenderUTF8_Blended(police, "Joueur 3 tapez votre pseudo et appuyez sur entrée.", couleurBlanc);
	else
		texte = TTF_RenderUTF8_Blended(police, "Joueur 4 tapez votre pseudo et appuyez sur entrée.", couleurBlanc);
    
    positionTxt.x = 50; positionTxt.y = 450;
    posAccueil.x = 0; posAccueil.y = 0;
    a = SDL_LoadBMP("accueil/menu-bg.bmp");
    SDL_BlitSurface(a, NULL, ecran, &posAccueil);
    SDL_BlitSurface(texte, NULL, ecran, &positionTxt);
    SDL_Flip(ecran);


    for(i=0;i<1;i++)
    {		
        SDL_BlitSurface(texte, NULL, ecran, &positionTxt);
        SDL_Flip(ecran);
        
        while(continuer)
        {
            //affiche_grille(ecran);
            SDL_WaitEvent(&event);

            switch(event.type)
            {
                case SDL_KEYDOWN:
                    switch (event.key.keysym.sym)
                    {
                        case SDLK_RETURN:
                            nom[i] = '\0';
                            continuer=0;
                            break;
                        case SDLK_KP_ENTER:
                            nom[i] = '\0';
                            continuer=0;
                            break;
                        case SDLK_a:
                            nom[i] = 'a';
                            break;
                        case SDLK_b:
                            nom[i] = 'b';
                            break;
                        case SDLK_c:
                            nom[i] = 'c';
                            break;
                        case SDLK_d:
                            nom[i] = 'd';
                            break;
                        case SDLK_e:
                            nom[i] = 'e';
                            break;
                        case SDLK_f:
                            nom[i] = 'f';
                            break;
                        case SDLK_g:
                            nom[i] = 'g';
                            break;
                        case SDLK_h:
                            nom[i] = 'h';
                            break;
                        case SDLK_i:
                            nom[i] = 'i';
                            break;
                        case SDLK_j:
                            nom[i] = 'j';
                            break;
                        case SDLK_k:
                            nom[i] = 'k';
                            break;
                        case SDLK_l:
                            nom[i] = 'l';
                            break;
                        case SDLK_m:
                            nom[i] = 'm';
                            break;
                        case SDLK_n:
                            nom[i] = 'n';
                            break;
                        case SDLK_o:
                            nom[i] = 'o';
                            break;
                        case SDLK_p:
                            nom[i] = 'p';
                            break;
                        case SDLK_q:
                            nom[i] = 'q';
                            break;
                        case SDLK_r:
                            nom[i] = 'r';
                            break;
                        case SDLK_s:
                            nom[i] = 's';
                            break;
                        case SDLK_t:
                            nom[i] = 't';
                            break;
                        case SDLK_u:
                            nom[i] = 'u';
                            break;
                        case SDLK_v:
                            nom[i] = 'v';
                            break;
                        case SDLK_w:
                            nom[i] = 'z';
                            break;
                        case SDLK_x:
                            nom[i] = 'x';
                            break;
                        case SDLK_y:
                            nom[i] = 'y';
                            break;
                        case SDLK_z:
                            nom[i] = 'w';
                            break;
                    }
                    i++;

                    break;
            }
            
        positionTxt.x = 100+i*12;
        positionTxt.y = 500;
        sprintf(texte," %c", nom[i-1]);
        texte = TTF_RenderUTF8_Blended(police, texte, couleurBlanc);
        SDL_BlitSurface(texte, NULL, ecran, &positionTxt);
        SDL_Flip(ecran);

        }

        t_nom=strlen(nom);

        pseudo=(char*)malloc(t_nom*sizeof(char));

        strcpy(pseudo,nom);

    }

	return;
}
