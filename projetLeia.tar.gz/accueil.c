#include "structures.h"

int type=0,nbjoueur=0;
piece *pj1=NULL,*pj2=NULL,*pj3=NULL,*pj4=NULL,*pord=NULL,*p=NULL,*pioche=NULL;
joueur *jrs;

void accueil(SDL_Surface *ecran)
{
	SDL_Event event;
	int continuer=1;
	SDL_Surface  *a=NULL,*bd=NULL,*bt=NULL,*bj=NULL,*bq=NULL,*bh=NULL,*bs=NULL;
	SDL_Rect posBdomino,posBtremino, posAccueil,posBjouer,posBquitter,posBhelp,posBstat;

	a = SDL_LoadBMP("accueil/menu-bg.bmp");
	bj=SDL_LoadBMP("accueil/button_jouer.bmp");
	bq=SDL_LoadBMP("accueil/button_quitter.bmp");
	bh=SDL_LoadBMP("accueil/button_help.bmp");
	bs=SDL_LoadBMP("accueil/button_stat.bmp");

	if(!a)
	{
		printf("Erreur de chargement de l'image : %s",SDL_GetError());   
	}
	
	posAccueil.x = 0; posAccueil.y = 0;
	posBjouer.x=471; posBjouer.y=280;
	posBquitter.x=471; posBquitter.y=380;
	posBhelp.x=471; posBhelp.y=480;
	posBstat.x=611; posBstat.y=480;
	
	ecran = SDL_SetVideoMode(1200, 800, 32, SDL_HWSURFACE);
        
	SDL_BlitSurface(a, NULL, ecran, &posAccueil);
	SDL_BlitSurface(bj,NULL,ecran,&posBjouer);
	SDL_BlitSurface(bq,NULL,ecran,&posBquitter);
	SDL_BlitSurface(bs,NULL,ecran,&posBstat);
	SDL_BlitSurface(bh,NULL,ecran,&posBhelp);
	SDL_Flip(ecran);
	
	while (continuer)
	{
    		SDL_WaitEvent(&event); 
    		switch(event.type) 
    		{
        		case SDL_QUIT : 
            			continuer = 0;
            			break;
			case SDL_MOUSEBUTTONUP:

				if (event.button.x>=posBquitter.x && event.button.x<=posBquitter.x+278 && event.button.y>=posBquitter.y && event.button.y<=posBquitter.y+80)
				{
					continuer=0;
					break;
				}
				else if (event.button.x>=posBjouer.x && event.button.x<=posBjouer.x+278 && event.button.y>=posBjouer.y && event.button.y<=posBjouer.y+80)
				{
					continuer=0;
					nb_joueur(ecran);
				}
    		}
		switch( event.key.keysym.sym )
        	{
        	case SDLK_ESCAPE: continuer = 0; break;
        	}
	}
	return;
}


void nb_joueur(SDL_Surface *ecran)
{
	SDL_Event event;
	int continuer=1,i;
	char *pseudo1=NULL, *pseudo2=NULL, *pseudo3=NULL, *pseudo4=NULL;
	
	SDL_Surface  *a=NULL,*bj1=NULL,*bj2=NULL,*bj3=NULL,*bj4=NULL;
	SDL_Rect posB1joueur,posB2joueur, posAccueil,posB3joueur,posB4joueur,posBhelp,posBstat;
	a = SDL_LoadBMP("accueil/menu-bg.bmp");
	bj1=SDL_LoadBMP("accueil/button_1joueur.bmp");
	bj2=SDL_LoadBMP("accueil/button_2joueurs.bmp");
	bj3=SDL_LoadBMP("accueil/button_3joueurs.bmp");
	bj4=SDL_LoadBMP("accueil/button_4joueurs.bmp");
	posAccueil.x = 0; posAccueil.y = 0;
	posB1joueur.x=471; posB1joueur.y=280;
	posB2joueur.x=471; posB2joueur.y=365;
	posB3joueur.x=471; posB3joueur.y=450;
	posB4joueur.x=471; posB4joueur.y=535;
	
	ecran = SDL_SetVideoMode(1200, 800, 32, SDL_HWSURFACE);
        
	SDL_BlitSurface(a, NULL, ecran, &posAccueil);
	SDL_BlitSurface(bj1,NULL,ecran,&posB1joueur);
	SDL_BlitSurface(bj2,NULL,ecran,&posB2joueur);
	SDL_BlitSurface(bj3,NULL,ecran,&posB3joueur);
	SDL_BlitSurface(bj4,NULL,ecran,&posB4joueur);
	SDL_Flip(ecran);
	
	while (continuer)
	{
    	SDL_WaitEvent(&event); 
    	switch(event.type) 
    	{
        	case SDL_QUIT : 
           		continuer = 0;
           		break;
			case SDL_MOUSEBUTTONUP:
				continuer=0;
				
				if(event.button.x>=posB1joueur.x && event.button.x<=posB1joueur.x+278 && event.button.y>=posB1joueur.y && event.button.y<=posB1joueur.y+80)
					nbjoueur=1;
				else if(event.button.x>=posB2joueur.x && event.button.x<=posB2joueur.x+278 && event.button.y>=posB2joueur.y && event.button.y<=posB2joueur.y+80)
					nbjoueur=2;
				else if(event.button.x>=posB3joueur.x && event.button.x<=posB3joueur.x+278 && event.button.y>=posB3joueur.y && event.button.y<=posB3joueur.y+80)
					nbjoueur=3;
				else if(event.button.x>=posB4joueur.x && event.button.x<=posB4joueur.x+278 && event.button.y>=posB4joueur.y && event.button.y<=posB4joueur.y+80)
					nbjoueur=4;
				
				jrs = (joueur*) malloc (nbjoueur*sizeof(joueur));
				
				for(i=0;i<nbjoueur;i++)
					nomJ(jrs[i].pseudo,i+1,ecran);
					
				type=2;
				jeu(ecran);
		}
		switch( event.key.keysym.sym )
		{
			case SDLK_ESCAPE: 
				continuer = 0; 
			break;
		}
	}
	return;
}

// Fonction qui permet d'accéder aux jeux triomino ou domino

void jeu(SDL_Surface *ecran)
{
	SDL_Event event;
	int continuer=1;
	SDL_Surface  *a=NULL,*bd=NULL,*bt=NULL,*bj=NULL,*bq=NULL;
	SDL_Rect posBdomino,posBtriomino, posAccueil,posBjouer,posBquitter;
	
	a = SDL_LoadBMP("accueil/menu-bg.bmp");
	bd=SDL_LoadBMP("accueil/button_dominos.bmp");
	bt=SDL_LoadBMP("accueil/button_triominos.bmp");
	posAccueil.x = 0;
	posAccueil.y = 0;
	posBdomino.x=471;
	posBdomino.y=315;
	posBtriomino.x=471;
	posBtriomino.y=415;
	ecran = SDL_SetVideoMode(1200, 800, 32, SDL_HWSURFACE);
    SDL_BlitSurface(a, NULL, ecran, &posAccueil);
	SDL_BlitSurface(bd,NULL,ecran,&posBdomino);
	SDL_BlitSurface(bt,NULL,ecran,&posBtriomino);
	SDL_Flip(ecran);

	while (continuer)
	{
    	SDL_WaitEvent(&event);
    	 
    	switch(event.type) 
    	{
       		case SDL_QUIT : 
           		continuer = 0;
           		break;
			case SDL_MOUSEBUTTONUP:
	
				if (event.button.x>=posBdomino.x && event.button.x<=posBdomino.x+278 && event.button.y>=posBdomino.y && event.button.y<=posBdomino.y+80)
				{
					continuer=0;
					p=init_dom(type);
					board_d(ecran);
					break;
				}
				else if (event.button.x>=posBtriomino.x && event.button.x<=posBtriomino.x+278 && event.button.y>=posBtriomino.y && event.button.y<=posBtriomino.y+80)
				{
					continuer=0;
					init_triomino(ecran);
				}
    	}
		switch( event.key.keysym.sym )
        {
        	case SDLK_ESCAPE: continuer = 0; 
        	break;
        }
        
	}
	return;
}
