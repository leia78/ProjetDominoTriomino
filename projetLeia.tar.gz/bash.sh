gcc accueil.c main.c pseudo.c domino.c triomino.c affiche_trio.c `sdl-config --cflags --libs` -lm -lSDL_ttf
