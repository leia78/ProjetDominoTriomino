#include "structures.h"

extern int nbjoueur;
extern int type;
extern piece *pj1,*pj2,*pj3,*pj4,*pord,*p, *pioche;
extern joueur *jrs;

piece *init_dom(int type)
{
	piece *p;
	int i,j,s=sizeof(piece),d=0,a=0, b=0;	
	p = (piece*) malloc (28*sizeof(piece));

	for(i=0;i<28;i++)
	{
		p[i].number = (int*) malloc (2*sizeof(int));
	}


	for(i=0;i<28;i++)
	{
		for(j=0;j<2;j++)
		{
			if(j==0)
			{
				p[i].number[j] = a;
			}
			else
			{
				p[i].number[j] = b;
				b++;
			}
			if(b==7)
			{
				a++;
				b=a;
			}
		}	
	}

	return p;
}

void board_d(SDL_Surface *ecran){
	SDL_Event event;
	int continuer=1,i;
	SDL_Surface  *a=NULL,*b=NULL;
	SDL_Rect  posAccueil,posBoard;
	a = SDL_LoadBMP("accueil/menu-bg.bmp");
	b=SDL_LoadBMP("accueil/board.bmp");
	posBoard.x=200;posBoard.y=150;
	ecran = SDL_SetVideoMode(1200, 800, 32, SDL_HWSURFACE);
	posAccueil.x = 0; posAccueil.y = 0;
	SDL_BlitSurface(a, NULL, ecran, &posAccueil);
	SDL_BlitSurface(b, NULL, ecran, &posBoard);
	melange(nbjoueur,p);
	distribuer(ecran);
	SDL_Flip(ecran);

	while (continuer)
	{
    	SDL_WaitEvent(&event); 
    	switch(event.type) 
    	{
       		case SDL_QUIT : 
           		continuer = 0;
           		break;
			/*case SDL_MOUSEBUTTONUP:

			if (event.button.x>=posB1joueur.x && event.button.x<=posB1joueur.x+278 && event.button.y>=posB1joueur.y && event.button.y<=posB1joueur.y+80)
			{
				continuer=0;p=init_piece(2);nbjoueur=1;board_d(ecran);break;
			}
			else if (event.button.x>=posB2joueur.x && event.button.x<=posB2joueur.x+278 && event.button.y>=posB2joueur.y && event.button.y<=posB2joueur.y+80)
			{
				break;
			}*/
    	}
		switch( event.key.keysym.sym )
        {
			case SDLK_ESCAPE: continuer = 0; break;
        }
	}
	
	return;

}
void melange(int nbjoueur,piece *p)
{
	int i,b;
	int randomIndex;
	piece *p1=NULL;
	srand(time(0));
	
	p1= (piece*) malloc (28*sizeof(piece));
	piece * temp = NULL;
	temp=(piece*) malloc(sizeof(piece));
	p1=p;
	
	for(i=0;i<28;i++)
	{
		temp[0]=p1[i];
    	randomIndex = rand() % 28;
    	p1[i] = p1[randomIndex];
		p1[randomIndex] = temp[0];		
	}
	
	if(nbjoueur==1)
	{
		pj1=(piece*) malloc(7*sizeof(piece));
		pord=(piece*) malloc(7*sizeof(piece));
		pioche=(piece*) malloc(14*sizeof(piece));
		for(i=0;i<7;i++)
		{
			pj1[i]=p1[i];
			pord[i]=p1[i+7];
		}	
		for(i=0;i<14;i++)
		{
		 	pioche[i]=p1[i+14];
		}			
	}
	else if(nbjoueur==2)
	{
		pj1=(piece*) malloc(7*sizeof(piece));
		pj2=(piece*) malloc(7*sizeof(piece));
		pioche=(piece*) malloc(14*sizeof(piece));
		for(i=0;i<7;i++)
		{
			pj1[i]=p1[i];
			pj2[i]=p1[i+7];
			
		}
		for(i=0;i<14;i++)
		{
		 	pioche[i]=p1[i+14];
		}
	}
	else if(nbjoueur==3)
	{
		pj1=(piece*) malloc(6*sizeof(piece));
		pj2=(piece*) malloc(6*sizeof(piece));
		pj3=(piece*) malloc(6*sizeof(piece));
		pioche=(piece*) malloc(10*sizeof(piece));
		for(i=0;i<7;i++)
		{
			pj1[i]=p1[i];
			pj2[i]=p1[i+6];
			pj3[i]=p1[i+12];
		}
		for(i=0;i<10;i++)
		{
		 	pioche[i]=p1[i+18];
		}
	}
	else if(nbjoueur==4)
	{
		pj1=(piece*) malloc(6*sizeof(piece));
		pj2=(piece*) malloc(6*sizeof(piece));
		pj3=(piece*) malloc(6*sizeof(piece));
		pj4=(piece*) malloc(6*sizeof(piece));
		pioche=(piece*) malloc(4*sizeof(piece));
		for(i=0;i<6;i++)
		{
			pj1[i]=p1[i];
			pj2[i]=p1[i+6];
			pj3[i]=p1[i+12];
			pj4[i]=p1[i+18];
		}
		for(i=0;i<4;i++)
		{
		 	pioche[i]=p1[i+24];
		}
	}
	return;
}

void distribuer(SDL_Surface *ecran)
{
	SDL_Surface *image=NULL,*back=NULL;
	
	SDL_Rect  posDj1,posDord,posDj2,posDj3,posDj4,posDpioche;
	posDj1.x=200;posDj1.y=680;
	posDord.x=200;posDord.y=10;
	posDpioche.x=1130;posDpioche.y=10;
	back=SDL_LoadBMP("domino/back.bmp");
	SDL_BlitSurface(back, NULL, ecran, &posDpioche);
	int i,l,h,e[10],u[2];
	char *s1 = ".bmp", *c; 
	
	if(nbjoueur==1)
	{
		for(i=0;i<7;i++)
		{
			l=pj1[i].number[0];
			h=pj1[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			SDL_BlitSurface(image, NULL, ecran, &posDj1);
			posDj1.x=posDj1.x+68;
		}
		for(i=0;i<7;i++)
		{
			l=pord[i].number[0];
			h=pord[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			
			SDL_BlitSurface(image, NULL, ecran, &posDord);
			SDL_BlitSurface(back, NULL, ecran, &posDord);
			posDord.x=posDord.x+68;
		}
			
	}
	else if(nbjoueur==2)
	{
		posDj1.x=200;posDj1.y=680;
		posDj2.x=200;posDj2.y=10;
		for(i=0;i<7;i++)
		{
			l=pj1[i].number[0];
			h=pj1[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			SDL_BlitSurface(image, NULL, ecran, &posDj1);
			posDj1.x=posDj1.x+68;
		}
		for(i=0;i<7;i++)
		{
			l=pj2[i].number[0];
			h=pj2[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDj2);
			//SDL_BlitSurface(back, NULL, ecran, &posDj2);
			posDj2.x=posDj2.x+68;
		}
	}	
	
	else if(nbjoueur==3)
	{
		posDj1.x=10;posDj1.y=680;
		posDj2.x=700;posDj2.y=680;
		posDj3.x=200;posDj3.y=10;
		for(i=0;i<6;i++)
		{
			l=pj1[i].number[0];
			h=pj1[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			SDL_BlitSurface(image, NULL, ecran, &posDj1);
			posDj1.x=posDj1.x+68;
		}
		for(i=0;i<6;i++)
		{
			l=pj2[i].number[0];
			h=pj2[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDj2);
			//SDL_BlitSurface(back, NULL, ecran, &posDj2);
			posDj2.x=posDj2.x+68;
		}
		for(i=0;i<6;i++)
		{
			l=pj3[i].number[0];
			h=pj3[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDj3);
			//SDL_BlitSurface(back, NULL, ecran, &posDj3);
			posDj3.x=posDj3.x+68;
		}
	}
	else if(nbjoueur==4)
	{
		posDj1.x=10;posDj1.y=680;
		posDj2.x=700;posDj2.y=680;
		posDj3.x=10;posDj3.y=10;
		posDj4.x=700;posDj4.y=10;
		for(i=0;i<6;i++)
		{
			l=pj1[i].number[0];
			h=pj1[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			SDL_BlitSurface(image, NULL, ecran, &posDj1);
			posDj1.x=posDj1.x+68;
		}
		for(i=0;i<6;i++)
		{
			l=pj2[i].number[0];
			h=pj2[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDj2);
			//SDL_BlitSurface(back, NULL, ecran, &posDj2);
			posDj2.x=posDj2.x+68;
		}
		for(i=0;i<6;i++)
		{
			l=pj3[i].number[0];
			h=pj3[i].number[1];
			sprintf(e,"domino/%d",l); 
				sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDj3);
			//SDL_BlitSurface(back, NULL, ecran, &posDj3);
			posDj3.x=posDj3.x+68;
		}
		for(i=0;i<6;i++)
		{
			l=pj4[i].number[0];
			h=pj4[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDj4);
			//SDL_BlitSurface(back, NULL, ecran, &posDj4);
			posDj4.x=posDj4.x+68;
		}
	}
	
	return;
	
}
char *concat(const char *s1, const char *s2){
    char *res = malloc(strlen(s1) + strlen(s2) + 1);
    if (res) {
        strcpy(res, s1);
        strcat(res, s2);
    }
    return res;
}
