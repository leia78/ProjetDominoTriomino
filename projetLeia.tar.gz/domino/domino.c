#include "structures.h"

extern int nbjoueur;
extern int type;
extern piece *pj1,*pj2,*pj3,*pj4,*pord,*p;

piece *init_dom(int type)
{
	piece *p;
	int i,j,s=sizeof(piece),d=0,a=0, b=0;	

	p = (piece*) malloc (28*sizeof(piece));

	for(i=0;i<28;i++)
		p[i].number = (int*) malloc (2*sizeof(int));

	for(i=0;i<28;i++)
	{
		for(j=0;j<2;j++)
		{
			if(j==0)
				p[i].number[j] = a;
			else{
				p[i].number[j] = b;
				b++;
			}
			if(b==7){
				a++;
				b=a;
			}
		}	
	}
	
	return p;
}

void melange(int nbjoueur,piece *p)
{
	int i,b;
	piece *p1=NULL;
	p1= (piece*) malloc (28*sizeof(piece));
	for(i=0;i<28;i++)
	{
		b =rand()%28;
		p1[i]= p[b];	
	}
	if(nbjoueur=1)
	{
		pj1=(piece*) malloc(7*sizeof(piece));
		pord=(piece*) malloc(7*sizeof(piece));
		for(i=0;i<7;i++)
		{
			pj1[i]=p1[i];
			pord[i]=p1[i+7];
		}				
	}
	return;
}

void distribuer(SDL_Surface *ecran)
{
	SDL_Surface *image=NULL,*back=NULL;
	SDL_Rect  posDj1,posDord;
	int i,l,h,e[2],u[2];
	char *s1 = ".bmp", *c; 
	
	posDj1.x=200;posDj1.y=680;
	posDord.x=200;posDord.y=10;
	
	if(nbjoueur=1)
	{
		for(i=0;i<7;i++)
		{
			l=pj1[i].number[0];
			h=pj1[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			SDL_BlitSurface(image, NULL, ecran, &posDj1);
			posDj1.x=posDj1.x+68;
		}
		for(i=0;i<7;i++)
		{
			l=pord[i].number[0];
			h=pord[i].number[1];
			sprintf(e,"domino/%d",l); 
			sprintf(u,"%d",h); 
			strcat(e,u);
			c = concat(e,s1);
			image = SDL_LoadBMP(c);
			back=SDL_LoadBMP("domino/back.bmp");
			SDL_BlitSurface(image, NULL, ecran, &posDord);
			SDL_BlitSurface(back, NULL, ecran, &posDord);
			posDord.x=posDord.x+68;
		}
	}
	return;
}

char *concat(const char *s1, const char *s2)
{
    char *res = malloc(strlen(s1) + strlen(s2) + 1);
    if (res) 
    {
        strcpy(res, s1);
        strcat(res, s2);
    }
    return res;
}

void board_d(SDL_Surface *ecran){
	SDL_Event event;
	int continuer=1,i;
	SDL_Surface  *a=NULL,*b=NULL;
	SDL_Rect  posAccueil,posBoard;
	a = SDL_LoadBMP("accueil/menu-bg.bmp");
	b=SDL_LoadBMP("accueil/board.bmp");
	posBoard.x=200;posBoard.y=150;

	posAccueil.x = 0; posAccueil.y = 0;
	SDL_BlitSurface(a, NULL, ecran, &posAccueil);
	SDL_BlitSurface(b, NULL, ecran, &posBoard);
	melange(nbjoueur,p);
	distribuer(ecran);
	SDL_Flip(ecran);
	for(i=0;i<7;i++)
	{
		printf("%d\t%d\n",pj1[i].number[0],pj1[i].number[1]);
		printf("%d\t%d\n",pord[i].number[0],pord[i].number[1]);
	}
	return;
}
