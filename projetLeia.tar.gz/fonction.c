#include"structures.h"
extern piece *pj1,*pj2,*pj3,*pj4,*pord,*p,*pioche;
extern int *ordre,nbjoueur,type;
char *concat(const char *s1, const char *s2){
    char *res = malloc(strlen(s1) + strlen(s2) + 1);
    if (res) {
        strcpy(res, s1);
        strcat(res, s2);
    }
    return res;
}
int maxpj(piece *p){
	int i=0,max=0;
	if(nbjoueur==1 || nbjoueur==2){
		
		for(i=0;i<7;i++)
			{
				if(p[i].number[0]==p[i].number[1]&&max<p[i].number[0]+p[i].number[1]){
									max=p[i].number[0]+p[i].number[1];
								}
			}	

	}
	else
	{
	
		for(i=0;i<6;i++)
			{
				if(p[i].number[0]==p[i].number[1]&&max<p[i].number[0]+p[i].number[1]){
									max=p[i].number[0]+p[i].number[1];
								}
			}	
	}
	
return max;
}
