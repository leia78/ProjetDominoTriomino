#!/bin/bash

gcc -Wall `sdl-config --cflags` accueil.c domino.c main.c pseudo.c triomino.c `sdl-config --libs` -lm -lSDL_ttf

